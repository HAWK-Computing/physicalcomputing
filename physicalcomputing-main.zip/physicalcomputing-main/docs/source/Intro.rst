Um was geht's im Kurs?

picozero https://picozero.readthedocs.io/en/latest/gettingstarted.html
